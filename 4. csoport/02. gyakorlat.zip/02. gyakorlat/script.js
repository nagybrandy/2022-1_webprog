const videogames = [
    {
        title: "League of Legends",
        year: 2009,
        genre: "MOBA",
        publisher: "Riot Games",
    }, 
    {
        title: "Rocket League",
        year: 2015,
        genre: "Sports",
        publisher: "Psyonixapex",
    },
    {
        title: "Apex Legends",
        year: 2019,
        genre: "Battle Royal",
        publisher: "EA",
    },

]